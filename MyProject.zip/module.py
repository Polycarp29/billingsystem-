#Admin login section 
#Staff login section 

import tkinter
from tkinter import * # Using Tkinter for python graphics 
from tkinter import font
from tkinter import filedialog as fd
from tkinter import messagebox
from mysql.connector import connect
import mysql.connector
import MySQLdb   #Connects the UI to mysql database 
import PIL.Image,PIL.ImageTk #This modules enables you to import pictures 
from tkinter import scrolledtext #Enables use of the ability to use the the scroll bar
from tkinter.filedialog import asksaveasfile

supermarket = Tk()
myfont = font.Font(family="Helvetica",size=13,weight="bold")
supermarket.geometry("900x800")
supermarket.title("Supermarket")
supermarket['background']= '#728FCE'
homepage = Frame(supermarket)




def details():
    username = username_variable.get()
    password = password_variable.get()
    database_login(username,password,member)
def select_image():
    filetypes = (
        ("image/jpg", "*.jpg"),
        ("image/png", "*.png")
    )
    file = fd.askopenfilename(title="Open a file", initialdir="/", filetypes=filetypes)
    image_pic_var.set(f'{file}')




#the below code helps you design  the admin page . the functions and variables are set to be defined in the codes below 
def admin_panel():
    homepage.place_forget()
    Admin_login_page.place_forget()
    admin_panel_frame = Frame(supermarket, width=1366, height=766)
    admin_panel_frame.place(x=0,y=0)
    add_item_label = Label(admin_panel_frame, text="ADD ITEM", font=myfont)
    add_item_label.pack()
    space_label = Label(admin_panel_frame, text=" ", font=myfont)
    space_label.pack()
    global image_name_var
    image_name_var = StringVar()
    image_name_var.set("Name of item")
    item_name_label = Label(admin_panel_frame, text="Item Name", font=myfont)
    item_name_label.pack()
    image_name = Entry(admin_panel_frame, fg="gray", font=myfont, textvariable=image_name_var)
    image_name.pack()
    space_label = Label(admin_panel_frame, text=" ", font=myfont)
    space_label.pack()
    global item_quantity_var
    item_quantity_var = DoubleVar()
    item_quantity_var.set(0.0)
    item_quantity_label = Label(admin_panel_frame, text="Item Quantity", font=myfont)
    item_quantity_label.pack()
    item_quantity_entry = Entry(admin_panel_frame, font=myfont, fg="gray", textvariable=item_quantity_var)
    item_quantity_entry.pack()
    space_label = Label(admin_panel_frame, text=" ", font=myfont)
    space_label.pack()
    global item_price_var
    item_price_var = DoubleVar()
    item_price_var.set(0.0)
    item_price_label = Label(admin_panel_frame, text="Item Price", font=myfont)
    item_price_label.pack()
    item_price_entry = Entry(admin_panel_frame, font=myfont, fg="gray", textvariable=item_price_var)
    item_price_entry.pack()
    space_label = Label(admin_panel_frame, text=" ", font=myfont)
    space_label.pack()
    global image_pic_var
    image_pic_var = StringVar()
    image_pic_var.set("Click on button to add an image")
    item_image_label = Label(admin_panel_frame, text="Item Image", font=myfont)
    item_image_label.pack()
    image_pic = Entry(admin_panel_frame,  font=myfont, fg="gray", textvariable=image_pic_var, width=50)
    image_pic.pack()
    space_label = Label(admin_panel_frame, text=" ", font=myfont)
    space_label.pack()
    
    add_button = Button(admin_panel_frame, text="Add Image", font=myfont, bg="blue", fg="white", command=select_image)
    add_button.pack(side="left")
    save_button = Button(admin_panel_frame, text="Save", font=myfont, bg="green", fg="white")
    save_button.pack(side="right")
    admin_panel_frame.place(anchor="c", rely=0.5, relx=0.5)





def get_item(item):
    db = connect(host="localhost", username="admin", password="mak8503", db="items")
    cursor = db.cursor()
    cursor.execute("select Name, Price from food")
    myfetch = cursor.fetchall()
    item_list ={}
    for item_name, price in myfetch:
        item_list[item_name] =  price

    return item_list[item]


   

def reset():
    purchases_scrolled_text.delete("1.0", END)
    item_name = Label(purchases_scrolled_text, text="Items"+(" "*22)+"|", font=myfont)
    quantity = Label(purchases_scrolled_text, text=(" "*8)+ "Quantity"+(" "*10)+"|", font=myfont)
    cost = Label(purchases_scrolled_text,text=(" "*9)+"Cost"+(" "*10),font=myfont)
    
    purchases_scrolled_text.window_create("end", window=item_name)
    purchases_scrolled_text.window_create("end", window=quantity)
    purchases_scrolled_text.window_create("end", window=cost)
    paid_amount_var.set(0.0)
    total_amount_var.set(0.0)
    balance_amount_var.set(0.0)

    
def checkout():
    balance = paid_amount_var.get() - total_amount_var.get()
    balance_amount_var.set(balance)


     #return a dictionary of items 
#The above code fetches price items from the database and prints them to the terminal 

def add():
    exec("global total_cost")
    exec("total_cost =0")
    
    for num in range(0,7):
        exp =f"(var_entry{num}.get() != 0.0)"
        
        if eval(exp):
            exec(f"item_name = label{num}['text']")
            exec(f"item_quantity = (var_entry{num}).get()")
            exec(f'price = get_item(item_name)')
            exec("txt = (item_name+(' '*10) + '|' + (' '*10) + 'x' + str(item_quantity)+(' '*8)+'|')+(' '*10)+(str(price*item_quantity))")
            exec("purchases_scrolled_text.insert(INSERT,txt)")
            purchases_scrolled_text.insert(INSERT,'\n')
            exec(f"var_entry{num}.set(0.0)")
            exec("total_cost += float(price)*item_quantity")
            exec("total_amount_var.set(total_cost)")


def register():
    username = name.get()
    emailid = email.get()
    contactid = contact.get()

    file = open(username+".txt","w")
    file.write(username + "\n")
    file.write(emailid )
    file.write(contactid)
    file.close
    messagebox.showinfo("Client Details Submitted successfully")

def search():
    text = item_scrolled_text
    text.tag_remove('found', '1.0', END)
     
    #returns to widget currently in focus
    s = searchentry.get()
    if s:
        idx = '1.0'
        while 1:
            #searches for desired string from index 1
            idx = text.search(s, idx, nocase=1,
                              stopindex=END)
            if not idx: break
             
            #last index sum of current index and
            #length of text
            lastidx = '%s+%dc' % (idx, len(s))
             
            #overwrite 'Found' at idx
            text.tag_add('found', idx, lastidx)
            idx = lastidx
         
        #mark located string as red
        text.tag_config('found', foreground='red')
    searchentry.focus_set()
    

    




       
            
def logout():
    supermarket.destroy()

def close():
    billing_page_frame.destroy()



def save_file():
    
    file= asksaveasfile(initialfile = 'Untitled.txt',
    defaultextension=".txt",filetypes=[("All Files","*.*"),("Text Documents","*.txt")])
    username =name_entry.get()
    emailid = email_entry.get()
    contactid = contact_entry.get()
    filedata=str(purchases_scrolled_text.get(1.0,END))
    total = str(total_amount_entry.get())
    paid = paid_amount_entry.get()
    balance = balance_amount_entry.get()
    file.write(username + "\n")
    file.write(emailid)
    file.write(contactid)
    file.write(filedata)
    file.write(total)
    file.write(paid)
    file.write(balance)
    
    file.close()


def billing_page():
    homepage.place_forget()
    global billing_page_frame
#Creating the billing page that inherits the properties from the main app
    billing_page_frame = Frame(supermarket, width= 1366,height=768,)
    billing_page_frame.place(x=0,y=0)
    welcoment= Label(billing_page_frame, text="WELCOME TO THIS BILLING SYSTEM", font=myfont, bg="blue" ,fg ="skyblue"  )
    welcoment.place(x=0,y=0, width="1366", height="30")
    global item_scrolled_text
    

    item_scrolled_text = scrolledtext.ScrolledText(billing_page_frame, width=40, height=30)
    
    item_scrolled_text.place(x=10, y=80)
    item_name = Label(item_scrolled_text, text="Items"+(" "*40)+"|", font=myfont)
    item_scrolled_text.images = []
    
    searchId = Label(billing_page_frame, text="Item ID" , font=myfont ,)
    searchId.place(x=0, y=50)
    global searchentry
    searchentry = Entry(billing_page_frame,text="Search ID",font=myfont)
    searchentry.place(x=70,y=50)
    search_button=Button(billing_page_frame, text="Search" ,bg="blue",fg="white", font=myfont , width=5 ,command= search)
    search_button.place(x=300, y=48 )
    close_button=Button(billing_page_frame, text="Logout" ,bg="blue",fg="Red", font=myfont , width=12 ,command=close)
    close_button.place(x=1200, y=630)
    #Submit user data
    global name 
    global email
    global contact
    global name_entry
    global email_entry
    global contact_entry

    name_entry = StringVar()
    email_entry = StringVar()
    contact_entry= StringVar()

    

    
    
    
    namelbl = Label(billing_page_frame, text="ClientName*" , font=myfont ,)
    namelbl.place(x=350, y=100)
    name_entry= Entry(billing_page_frame,textvariable="name",font=myfont)
    name_entry.place(x=450,y=100)
    emaillbl = Label(billing_page_frame, text="Email *" , font=myfont ,)
    emaillbl.place(x=350, y=150)
    email_entry = Entry(billing_page_frame,text="email",font=myfont)
    email_entry.place(x=450,y=150)
    contactlbl = Label(billing_page_frame, text="Contact *" , font=myfont ,)
    contactlbl.place(x=350, y=200)
    contact_entry = Entry(billing_page_frame,text="contact",font=myfont)
    contact_entry.place(x=450,y=200)
    submit=Button(billing_page_frame, text="Submit" ,bg="blue",fg="Red", font=myfont , width=12  ,command=register)
    submit.place(x=450, y=250)





    
    #creating a button for the items 
    add_button = Button(billing_page_frame, text="Add", bg="skyblue", fg="white",font=myfont, width=15 , command=add)
    add_button.place(x=50, y=650)
    reset_button = Button(billing_page_frame, text="Reset", bg="blue",fg="white" , font=myfont, width=15 ,command= reset)
    reset_button.place(x=170,y=650)
    global purchases_scrolled_text

    purchases_scrolled_text = scrolledtext.ScrolledText(billing_page_frame, width=60, height=15)  #this code adds colums on the selected scrolled list.
    purchases_scrolled_text.place(x=760, y=70 )
    item_name = Label(purchases_scrolled_text, text="Items"+(" "*20)+"|", font=myfont)
    quantity = Label(purchases_scrolled_text, text=(" "*10)+ "Quantity"+(" "*10)+"|", font=myfont)
    cost = Label(purchases_scrolled_text,text=(" "*9)+"Cost"+(" "*10),font=myfont)
    
    purchases_scrolled_text.window_create("end", window=item_name)
    purchases_scrolled_text.window_create("end", window=quantity)
    purchases_scrolled_text.window_create("end", window=cost)
    global total_amount
    total_amount = Label(billing_page_frame, text="Total",font=myfont)
    total_amount.place(x=760,y=480)
    paid_amount = Label(billing_page_frame, text="Paid Amount",font=myfont)
    paid_amount.place(x=760,y=540)
    balance_amount = Label(billing_page_frame,text="Balance",font=myfont)
    balance_amount.place(x=760,y=600)
    global total_amount_var
    total_amount_var = DoubleVar()
    global paid_amount_var
    paid_amount_var = DoubleVar()
    global balance_amount_var
    balance_amount_var = DoubleVar()
    global total_amount_entry
    total_amount_entry = Entry(billing_page_frame, font=myfont,textvariable=total_amount_var)
    total_amount_entry.place(x=880,y=480)
    global paid_amount_entry
    paid_amount_entry = Entry(billing_page_frame, font=myfont,textvariable=paid_amount_var)
    paid_amount_entry.place(x=880,y=540)
    global balance_amount_entry
    balance_amount_entry = Entry(billing_page_frame, font=myfont, textvariable=balance_amount_var)
    balance_amount_entry.place(x=880,y=600)
    checkout_button = Button(billing_page_frame, text="Checkout", bg="navyblue", fg="red",font=myfont, width=15,command=checkout)
    checkout_button.place(x=800, y=650)
    global label0,label1,label2,label3,label4,label5,label6,var_entry0,var_entry1,var_entry2,var_entry3,var_entry4,var_entry5,var_entry6  #Setting label and var_entry to global 
    print_button = Button(billing_page_frame, text="Save Bill", bg="black", fg="white",font=myfont, width=15 , command=save_file)
    print_button.place(x=970, y=650)
    logout_button = Button(billing_page_frame, text="Close", bg="skyblue", fg="white",font=myfont, width=12, command=logout)
    logout_button.place(x=1200, y=670)

    image0 = PIL.Image.open("/home/poltech/Music/MyProject/images/apple.jpeg")
    img0 = PIL.ImageTk.PhotoImage(image0.resize((50,50),PIL.Image.ANTIALIAS))
    item_scrolled_text.image_create(INSERT,padx=5,pady=5,image=img0,)
    item_scrolled_text.images.append(img0)
    label0 = Label(item_scrolled_text, text="Apple")
    var_entry0 = DoubleVar()
    Entry0 = Entry(item_scrolled_text, textvariable=var_entry0,width=20)
    item_scrolled_text.window_create("end",window=label0)
    item_scrolled_text.window_create("end",window=Entry0)

    image1 = PIL.Image.open("/home/poltech/Music/MyProject/images/bar.jpeg")
    img1 = PIL.ImageTk.PhotoImage(image1.resize((50,50),PIL.Image.ANTIALIAS))
    item_scrolled_text.image_create(INSERT,padx=5,pady=5,image=img1,)              #This codes adds items on scrolled text 
    item_scrolled_text.images.append(img1)
    label1 = Label(item_scrolled_text, text="BarSoap")
    var_entry1 = DoubleVar()
    Entry1 = Entry(item_scrolled_text, textvariable=var_entry1, width=20)
    item_scrolled_text.window_create("end",window=label1)
    item_scrolled_text.window_create("end",window=Entry1)


    image2 = PIL.Image.open("/home/poltech/Music/MyProject/images/cooking.jpeg")
    img2 = PIL.ImageTk.PhotoImage(image2.resize((50,50),PIL.Image.ANTIALIAS))
    item_scrolled_text.image_create(INSERT,padx=5,pady=5,image=img2, )
    item_scrolled_text.images.append(img2)
    label2 = Label(item_scrolled_text, text="CookingOil")
    var_entry2 = DoubleVar()
    Entry2 = Entry(item_scrolled_text, textvariable=var_entry2, width =15)
    item_scrolled_text.window_create("end",window=label2)
    item_scrolled_text.window_create("end",window=Entry2)


    image3 = PIL.Image.open("/home/poltech/Music/MyProject/images/sugar.jpeg")
    img3 = PIL.ImageTk.PhotoImage(image3.resize((50,50),PIL.Image.ANTIALIAS))
    item_scrolled_text.image_create(INSERT,padx=5,pady=5,image=img3)
    item_scrolled_text.images.append(img3)
    label3 = Label(item_scrolled_text, text="Sugar")
    var_entry3 = DoubleVar()
    Entry3 = Entry(item_scrolled_text, textvariable=var_entry3, width=20)
    item_scrolled_text.window_create("end",window=label3)
    item_scrolled_text.window_create("end",window=Entry3)


    image4 = PIL.Image.open("/home/poltech/Music/MyProject/images/salt.jpeg")
    img4 = PIL.ImageTk.PhotoImage(image4.resize((50,50),PIL.Image.ANTIALIAS))
    item_scrolled_text.image_create(INSERT,padx=5,pady=5,image=img4)
    item_scrolled_text.images.append(img4)
    label4 = Label(item_scrolled_text, text="TableSalt")
    var_entry4 = DoubleVar()
    Entry4 = Entry(item_scrolled_text, textvariable=var_entry4, width=20)
    item_scrolled_text.window_create("end",window=label4)
    item_scrolled_text.window_create("end",window=Entry4)

    image5 = PIL.Image.open("/home/poltech/Music/MyProject/images/nodules.jpeg")
    img5 = PIL.ImageTk.PhotoImage(image5.resize((50,50),PIL.Image.ANTIALIAS))
    item_scrolled_text.image_create(INSERT,padx=5,pady=5,image=img5)
    item_scrolled_text.images.append(img5)
    label5 = Label(item_scrolled_text, text="Nodules")
    var_entry5 = DoubleVar()
    Entry5 = Entry(item_scrolled_text, textvariable=var_entry5, width=20)
    item_scrolled_text.window_create("end",window=label5)
    item_scrolled_text.window_create("end",window=Entry5)

    image6 = PIL.Image.open("/home/poltech/Music/MyProject/images/bathing.jpeg")
    img6 = PIL.ImageTk.PhotoImage(image6.resize((50,50),PIL.Image.ANTIALIAS))
    item_scrolled_text.image_create(INSERT,padx=5,pady=5,image=img6)
    item_scrolled_text.images.append(img6)
    label6 = Label(item_scrolled_text, text="Bathing")
    var_entry6= DoubleVar()
    Entry6 = Entry(item_scrolled_text, textvariable=var_entry6, width=20)
    item_scrolled_text.window_create("end",window=label6)
    item_scrolled_text.window_create("end",window=Entry6)



    #Search ID 
   

   


    



def database_login(username,password, role):
    if role =="Staff":
        database = connect (host = "localhost", username="admin", password="mak8503", db="staffs") #Used mysql workbench to connect to the tkinter user interface 
        db = database.cursor()
        db.execute("select Name, password from Staff_Details")
        queries = db.fetchall()
        staff_list = {} #the staff details should be equal to a dictionary.
        for x,y in queries:
            staff_list[x.lower()] = y

        if username.lower() in staff_list.keys():
            if password == staff_list[username.lower()]:
                billing_page() #Brings the log in page after user authentications
            else:
                messagebox.showerror("Error","Incorrect Password or Username  Access is Denied!!!")

           


    elif role == "Admin":
        database =connect (host="localhost", username=username, password=password,db="staffs")
        db = database.cursor()
        db.execute("show databases")
        queries = db.fetchall()
        for x in queries:
            print(x)
            if db:
                admin_panel()
            else:
                messagebox.showerror("Access Denied")
            

              
    
    
def check_member():
    global member 
    member = radio_btn_variable.get()
    if  member == "Staff":
     Staff_login()   
    else:
        Admin_login()

def Staff_login():
    homepage.place_forget()
    Staff_login_page = Frame(supermarket, height=700)
    welcome_label2= Label(Staff_login_page, text="STAFF LOGIN PAGE",font=myfont)
    welcome_label2.pack()
    canvas2 = Canvas(Staff_login_page)
    line1 = canvas2.create_line(70,20,300,20)
    canvas2.pack(side=TOP)
    global username_variable #Makes the variable username a global variable 
    username_variable = StringVar()
    global password_variable #Assigns the password variable a global varaible 
    password_variable = StringVar()
    username_label = Label(Staff_login_page, text="Username", font=myfont)
    username_label.place(x=150, y=100)
    username_entry = Entry(Staff_login_page,font=myfont,textvariable=username_variable)
    username_entry.place(x=150, y=130)
    password_label = Label(Staff_login_page, text="Password", font=myfont)
    password_label.place(x=150, y=160)
    password_entry = Entry(Staff_login_page, font=myfont,textvariable=password_variable, show="*")
    password_entry.place(x=150, y=200)
    login_btn = Button(Staff_login_page, text="LOGIN", relief="flat",bg="blue",font=myfont ,fg="white",borderwidth="5", command=details)
    login_btn.place(x=150, y=250)
    Staff_login_page.place(anchor='c',rely=0.5,relx=0.5)
def Admin_login():
    homepage.place_forget()
    global Admin_login_page
    Admin_login_page = Frame(supermarket, height=700)
    welcome_label1= Label(Admin_login_page, text="ADMIN LOGIN PAGE",font=myfont)
    welcome_label1.pack()
    canvas1= Canvas(Admin_login_page)
    line2= canvas1.create_line(70,20,300,20)
    canvas1.pack(side=TOP)
    global username_variable
    username_variable = StringVar()
    global password_variable
    password_variable = StringVar()
    username_label = Label(Admin_login_page, text="Username", font=myfont)
    username_label.place(x=150, y=100)
    username_entry = Entry(Admin_login_page,font=myfont,textvariable=username_variable)
    username_entry.place(x=150, y=130)
    password_label = Label(Admin_login_page, text="Password", font=myfont)
    password_label.place(x=150, y=160)
    password_entry = Entry(Admin_login_page, font=myfont,textvariable=password_variable,show="*")
    password_entry.place(x=150, y=200)
    login_btn = Button(Admin_login_page, text="LOGIN",relief="flat",bg="blue",font=myfont,fg="white", borderwidth="5",command=details)
    login_btn.place(x=150, y=250)
    
    Admin_login_page.place(anchor='c',rely=0.5,relx=0.5)


    
welcome_label = Label(homepage, text="Welcome to this Supermarket Billing System",font=myfont,)
radio_btn_variable = StringVar()
staff_radio_btn =Radiobutton(homepage, value="Staff", variable=radio_btn_variable, text = "Staff",font=myfont)
admin_radio_btn = Radiobutton(homepage, value="Admin",variable=radio_btn_variable, text= "Admin" ,font=myfont)
select_membership = Button(homepage, text="Continue", relief="flat",bg ="violet", fg="white",font = myfont,command=check_member)
welcome_label.pack()
staff_radio_btn.pack()
admin_radio_btn.pack()
select_membership.pack()
homepage.place(anchor='c', rely=0.5, relx=0.5)
supermarket.mainloop()
